package com.java.ex;

import java.util.Date;

public class DateEx1 {

	public static void main(String[] args) {
		Date obj = new Date();
		System.out.println(obj);
	}
}
