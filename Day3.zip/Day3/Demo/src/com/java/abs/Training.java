package com.java.abs;

public abstract class Training {
	public abstract void name();
	public abstract void email();
}
