package com.java.intf;

public class Prakash implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Prakash...");
	}

	@Override
	public void email() {
		System.out.println("Email is prakash@gmail.com");
	}

}
