package com.java.intf;

public class Shivananda implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Shivananda...");
	}

	@Override
	public void email() {
		System.out.println("Email is shivananda@gmail.com");
	}

}
