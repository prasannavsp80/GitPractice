package com.java.oops;

public class Example4 {

	boolean flag;
	public static void main(String[] args) {
		Example4 obj = new Example4();
		System.out.println(obj.flag);
	}
}
