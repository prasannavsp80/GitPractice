package com.java.oops;

public class Test {
	    int a,b;
//	    a=5;
//	    b=7;
}
