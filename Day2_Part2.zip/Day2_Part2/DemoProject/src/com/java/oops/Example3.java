package com.java.oops;

public class Example3 {

	int i;
	public static void main(String[] args) {
		Example3 obj = new Example3();
		System.out.println(obj.i);
	}
}
