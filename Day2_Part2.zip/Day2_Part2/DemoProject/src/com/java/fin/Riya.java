package com.java.fin;

public class Riya extends Training {

	@Override
	public void name() {
		System.out.println("Name is Riya...");
	}

	@Override
	public void email() {
		System.out.println("Email is riya@gmail.com");
	}

}
