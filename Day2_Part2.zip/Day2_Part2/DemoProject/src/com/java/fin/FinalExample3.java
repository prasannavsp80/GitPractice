package com.java.fin;

final class Test {
	public void show() {
		System.out.println("Show From Class First...");
	}
}

//class Demo extends Test {
//	
//}


// Final Class cannot be Inherited further...

public class FinalExample3 {

}
