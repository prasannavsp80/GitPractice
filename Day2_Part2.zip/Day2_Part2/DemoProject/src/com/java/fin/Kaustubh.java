package com.java.fin;

public class Kaustubh extends Training {

	@Override
	public void name() {
		System.out.println("Name is Kaustubh...");
	}

	@Override
	public void email() {
		System.out.println("Email is kaustubh@gmail.com");
	}

}
