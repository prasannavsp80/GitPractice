package com.java.day2;

public class Afiya extends Employ {

	public Afiya(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
