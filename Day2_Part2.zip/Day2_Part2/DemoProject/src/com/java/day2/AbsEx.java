package com.java.day2;

public class AbsEx {

	public static void main(String[] args) {
		Employ obj1 = new Afiya(1, "Afiya", 62311);
		Employ obj2 = new Vaishnavi(3, "Vaishnavi", 90042);
		
		obj1.show();
		obj2.show();
	}
}
