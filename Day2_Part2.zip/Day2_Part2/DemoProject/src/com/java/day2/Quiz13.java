package com.java.day2;

public class Quiz13 {

	public static void main(String[] args) {
		boolean status1 = ( 5.0  <=  6.0)  &&  ( 4  <  5);
		boolean status2 = ( 10  !=  10)  ||  (10 == 10);
		System.out.println("status1: "+ status1 + "status2:" + status2);
	}
}
