package com.java.day2;

public class Quiz10 {

	void test (String x) {
//		switch (x) {
//		case 1:
//		case 2:
//		case 0:
//		default:
//		case 4:
		}}

