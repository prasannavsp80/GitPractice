package com.java.day2;

public class Quiz15 {

	public static void main(String[] args) {
		  for(;;) {
			   System.out.println("Hello");
			   }

	}
}
