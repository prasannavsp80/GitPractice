package com.java.day2;

public class Example1 {

	public static void main(String[] args) {
		int i=0;
		do {
			System.out.println("Welcome to Java...");
			i++;
		}while(i < 10);
	}
}
