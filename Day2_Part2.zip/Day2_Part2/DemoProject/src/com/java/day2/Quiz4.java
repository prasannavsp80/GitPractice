package com.java.day2;

public class Quiz4 {

	public static void main(String[] args) {
		boolean flag=true;
		if(flag) {
			System.out.println("Hi");
		} else {
			System.out.println("Bye");
		}
	}
}
