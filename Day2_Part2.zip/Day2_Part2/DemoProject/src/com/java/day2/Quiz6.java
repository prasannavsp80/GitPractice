package com.java.day2;

public class Quiz6 {

	public static void main(String[] args) {
		int b=4;
		b--;
		System.out.println(--b);
		System.out.println(b);	

	}
}
