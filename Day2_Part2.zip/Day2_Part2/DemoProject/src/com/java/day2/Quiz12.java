package com.java.day2;

public class Quiz12 {

	public static void main(String[] args) {
		int i=9;
		while(i<10  && i >24){
			
		  }
// while loop will not execute if the condition is false
	}
}
