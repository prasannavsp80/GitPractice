package com.java.day2;

public class Quiz5 {

	public static void main(String[] args) {
		String flag="true";
//		if(flag) {
//			System.out.println("Hi");
//		} else {
//			System.out.println("Byee");
//		}
	}
}
