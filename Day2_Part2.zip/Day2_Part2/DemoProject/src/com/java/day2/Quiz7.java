package com.java.day2;

public class Quiz7 {

	public static void main(String[] args) {
		int p = 1; 
		int q = 3;
		int m = p++ + --q;
		System.out.println(m++);
	}
}
