package com.java.day2;

public class Quiz11 {

	public static void main(String[] args) {
		int counter = 0;
		  for(int i = 5;  i > 0 ; i-- ) {
		        if( i % 2 != 0){
		            counter++;
		        }
		   }
		  System.out.println(counter);

	}
}
