package com.java.intf;

public interface I1 {
	void show();
}
