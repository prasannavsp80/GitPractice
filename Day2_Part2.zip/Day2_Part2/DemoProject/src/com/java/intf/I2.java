package com.java.intf;

public interface I2 {
	void display();
}
