public class Prog2 {
   public static void main(String[] args) {
	System.out.println(args[0]);
	System.out.println(args[2]);
  }
}

// java Prog2 Afiya Bhavitha Hari

