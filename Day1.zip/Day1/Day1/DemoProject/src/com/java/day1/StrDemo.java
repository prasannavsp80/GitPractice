package com.java.day1;

public class StrDemo {
	public static void main(String[] args) {
		String str="Hello";
		String result = str.concat(" World");
		System.out.println(result);
	}
}
