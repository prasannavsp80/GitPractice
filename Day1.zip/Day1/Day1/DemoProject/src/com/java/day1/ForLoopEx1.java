package com.java.day1;

public class ForLoopEx1 {
	public static void main(String[] args) {
		int n=10;
		for(int i=0;i<n;i++) {
			System.out.println("Welcome to Java Programming...");
		}
	}
}
