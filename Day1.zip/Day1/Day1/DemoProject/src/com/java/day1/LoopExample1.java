package com.java.day1;

public class LoopExample1 {

	public static void main(String[] args) {
		int n=10;
		int i=0;
		while(i < n) {
			System.out.println("Welcome to Java Programming..");
			i++;
		}
	}
}
