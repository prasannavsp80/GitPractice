import java.util.Scanner;
public class Scan2 {
   public static void main(String[] args) {
	String greeting;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Greeting   ");
	greeting = sc.nextLine();
	System.out.println(greeting);
   }
}