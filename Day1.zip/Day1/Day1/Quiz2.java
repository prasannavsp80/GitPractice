public class Quiz2 {
   public static void main(String[] args) {
	int i=12;
	System.out.println(i++ + i++ + ++i + ++i);
	// 12 + 13 + 15 + 16
   }
}

