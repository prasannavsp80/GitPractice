package com.java.day2;

public class Quiz3 {

	public static void main(String[] args) {
        String a = "Sam";
       int b= 10,c=20,d=30;
       System.out.println(a+b+c+d); // sam102030
      System.out.println(b+c+d+a); // 60sam
      System.out.println(b+c+a+d);//30sam30

	}
}
