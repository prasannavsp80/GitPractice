package com.java.day2;

public class Quiz8 {

	public static void main(String[] args) {
		int[] a = new int[] {4,2,55,23};
		int[] b = a;
		for(int i=0;i<b.length;i++) {
			System.out.println(b[i]);
		}
	}
}
