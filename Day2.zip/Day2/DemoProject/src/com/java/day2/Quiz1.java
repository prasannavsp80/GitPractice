package com.java.day2;

public class Quiz1 {

	public static void main(String[] args) {
		int i=10;
		do {
			i--;
		}while(i < 10);
	}
}


// Executes infinite times


