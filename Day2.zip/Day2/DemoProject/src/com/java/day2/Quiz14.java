package com.java.day2;

public class Quiz14 {

	public static void main(String[] args) {
	     char ch = 'a';  
	     switch (ch){
	           case 'a':
	           case 'A': 
	            System.out.print(ch); 
	           case 'b':
	           case 'B':
	            System.out.print(ch); break;
	     }
	}
}
