package com.java.day2;

public class Quiz16 {

	public static void main(String[] args) {
		int i;
		//System.out.println(i++);
		
		// Compile Time Error as use of unassigned variable
	}
}
